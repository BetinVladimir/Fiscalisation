# Browser legacy BLE reliability — implemented candidate, review pending

2026-10-21. Original Fiscalisation repository remains read-only. This isolated patch changes two browser classes, two identical local lifecycle helpers and one actual-class fake-WebBluetooth test suite. No firmware, new stream/TLS/UUID, security-mode enablement, financial fallback/retry, NVS keys or external secure-element changes. ESP32-S3/NVS remains the only key storage; ATECC608A/608 is not used.

## Public API and financial compatibility

`WebBleBootstrap` keeps existing methods/return shapes, including `OPEN_READY`. Optional trailing `AbortSignal` is added to connect and both send methods. Existing operation timeout remains 30s default, caller integer100..120000ms. The supplied MTU now actually reaches framing from `sendComplianceIntentAndWait` (previously ignored). Mode remains `OPEN_MVP` only; unsupported encrypted mode still fails closed. Expiry must parse and remain in the future before setup, each write and result publication.

`WebBleRoute` keeps its configuration, `submit/submitCommand`, `kind/probe/lookup` and existing state/certainty conversion. Its existing required signal controls the whole operation; the post-selection result budget remains120s. RouteController's persisted attempt/UNKNOWN/recovery behavior is unchanged. A successful write/fragment receipt does not prove fiscal completion. An early fiscal result cannot release a hung write.

Each instance has one admitted connection attempt and one sending/waiting operation. Overlap fails before additional I/O. Owner identity is a nonreused object generation, checked after every SDK await and async result continuation. No automatic reconnect, financial retry, alternate route or operation-ID substitution is introduced.

## Accepted legacy wire decision

Default185 remains an explicit legacy ATT MTU offer, producing at most182-byte values. This is **not** a negotiated browser MTU guarantee. BFF1's57-byte header needs a nonempty fragment: minimum value58 / MTU61. ATT MTU23 / value20 is unsupported by this legacy protocol; default-ATT interoperability requires the separately reviewed new stream path.

BeeMiniPOS explicit MTU61..515 is accepted; larger values are rejected before write because ATT attribute values are bounded512. MTU517 previously allowed the shared framer to generate514-byte values. The shared/native framer is unchanged; this adapter rejects the invalid offer rather than silently resize it. PWA retains fixed185. Any browser length rejection closes/rejects after exactly the attempted write, without downsizing, rechunking or resubmission.

## Ownership, admission and deadlines

Two local copies of `BrowserGattOwner` avoid adding a cross-app packaging dependency; their source hashes are identical. Each helper uses both a WeakMap keyed by GATT object and a bounded32-entry Map keyed by opaque origin-scoped `BluetoothDevice.id` (nonempty, max512characters). The id is a lifecycle key, never authenticated identity. This covers same-device/new-JS-wrapper ABA within the app module lifetime.

Cancellation invalidates the owner first, removes exact event/abort listeners and timers, rejects all waits, and disconnects the old link. If a native SDK promise is pending, admission is retained until it settles; a replacement using the same GATT **or same device.id** is rejected with `BLE_CONNECTION_DRAINING`. Late settlement synchronously disconnects the retired link before releasing admission. All32 unresolved native calls exhaust the bounded admission table and fail closed with `BLE_CONNECTION_CAPACITY`; no unbounded allocation. A never-settling platform promise can require page restart for that device, intentionally preferring failure over a late old connect affecting a replacement. Cross-tab, cross-bundle and OS connection coordination remain OPEN.

Notification and disconnect listeners are installed before subscription. Every connection/service/characteristic/subscription call has10s deadline and setup has30s absolute budget after selection. Each acknowledged write has5s deadline; existing operation/result deadlines also apply and cannot be extended by fragments. User chooser has no timer but is abortable; a late chooser resolution never starts a connect. Abort signals already cancelled before entry cause no chooser/I/O. No asynchronous `stopNotifications` cleanup can disable a newer subscription.

Only `writeValueWithResponse` is used; deprecated ambiguous `writeValue` fallback is removed. Once any write is attempted, timeout/rejection remains uncertain through the unchanged higher-level recovery flow.

## Byte ownership and bounds

Notification `DataView` bytes are copied immediately with exact offset/length. Values outside58..512 are ignored by MiniPOS or rejected by PWA under their existing malformed-event policies. Wrong message IDs are filtered before assembly. Only the current operation's ID can publish events/results. Assemblies are replaced per operation and bounded to8192 payload bytes; positive fragment length bounds fragment count8192.

PWA replaces its unbounded Map/parts array with one preallocated8192-max payload and validates magic, total, offset, exact final marker, remaining length and digest. Only one async final digest may be in flight; further data fails closed. BeeMiniPOS's existing shared assembler remains unchanged (already bounded4states), but adapter admission restricts it to one expected ID and replaces it on completion/reset. Duplicate/stale completions cannot publish into another owner/operation.

## Verification and remaining scope

Direct tests instantiate both real exported classes against a fake WebBluetooth SDK, using real CBOR/hash implementations and independent BFF1 reply construction. They cover all five SDK setup stages with rejection/abort/deadline, listener-before-subscribe, synchronous disconnect, chooser cancellation, same-GATT and same-id/different-wrapper admission, bounded32 pending admissions/release, per-write/result budgets, early result+hung write, no retry after length rejection, foreign-ID floods, malformed bounds/final/digest, offset DataView copy, stale hash/callback/write settlement, overlap rejection, exact listener/timer cleanup, explicit61 framing and invalid/expired sessions. No device access occurs.

See `RESULTS.md`, logs and `TESTED_SOURCE.json` for exact evidence. Original-source regression tests and a counterfactual removing stable-id admission must be RED. This package is ordinary browser transport reliability only: secure BLE authentication/encryption, new stream integration, real ATT sizing/throughput, reconnect across tabs/OS, physical Android/iOS/browser HIL, S3 heap/latency and certification remain OPEN.
