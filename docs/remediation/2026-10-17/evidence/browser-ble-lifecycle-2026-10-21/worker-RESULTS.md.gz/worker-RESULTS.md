# Browser legacy BLE reliability candidate — review evidence

2026-10-21. Original repository was read-only throughout. Patch is scoped to five files: two actual transport classes, two identical local `browserGatt.ts` helpers, one direct actual-class test suite. Exact final SHA256 values are in `TESTED_SOURCE.json`; `git apply --check` against the recorded original HEAD passes. No original code/config/dependencies, globals, device firmware, NVS keys or physical devices were changed.

## Final verification

| Check | Result | Raw evidence |
|---|---|---|
| Actual BeeMiniPOS + PWA transport lifecycle tests | 64 PASS (included in PWA full suite) | `preference-and-lifecycle-rerun.log`: 79 PASS =64transport+15existingpreference |
| Full PWA Vitest suite | 362 PASS /48files, exit0 | `pwa-full-final.log` |
| Full MiniPOS existing Node suite | 234 PASS, exit0 | `mini-full-final.log` |
| Both complete app TypeScript checks | PASS, exit0 | `mini-ts-final.log`, `pwa-ts-final.log` (empty success output) |
| PWA production Vite bundle | PASS | `pwa-build-final.log` |
| Actual MiniPOS transport browser-target esbuild bundle | PASS,103KiB | `mini-transport-browser-build.log`; verifies browser-target code, not full Expo application |
| Original source regression checks | RED:6FAIL, intentional pre-fix evidence | `original-red.log` (the same six selected regressions; earlier test-suite size28) |
| Remove stable device.id admission only | RED:both same-id/new-wrapper tests observe an unexpected connect | `stable-id-counterfactual-red.log`, `counterfactual.json` |
| Restore exact final helpers | GREEN:2PASS | `stable-id-restored-green.log`; helper hashes match final manifest |
| Original-target patch apply check | PASS | `apply-check.log` |

A full-suite repeat produced one unrelated existing preference focus timing failure (361PASS/1FAIL): `pwa-full-focus-flake.log`. No preference code/assertion was changed. Subsequent targeted preference+BLE rerun79/79 and final full362/362 passed. This evidence preserves the failure rather than claiming every repeat was clean.

Initial broad PWA run lacked copied docs/Go toolchain path/backend fixtures, producing environment failures (`pwa-full.log`). Final run uses read-only original docs/contracts/shared-ui references, a source-only copied backend, local Go PATH and synthetic in-memory domain fixtures. Go tests produce their synthetic authorization fixtures only under `/private/tmp`; none are included in the package.

## Full Expo application export limitation

`mini-build-final.log` records an OPEN isolated-copy build gate: Metro cannot resolve `react-native-web` through linked dependency realpaths. The first linked Expo AppEntry attempt also resolved App relative to its original package path; copying only the Expo package locally advanced to the next linked dependency failure. No project source workaround or original dependency mutation was made. Full MiniPOS Expo export should be rerun by root against the normal dependency installation after review. The successful standalone transport browser bundle is explicitly narrower evidence.

## Reproduction

After applying the patch in an ordinary complete checkout with installed dependencies:

```sh
cd minipos/miniposweb
node node_modules/vitest/vitest.mjs run tests/webBleLifecycle.test.ts --reporter=verbose
node node_modules/vitest/vitest.mjs run
node node_modules/typescript/bin/tsc --noEmit
node node_modules/vite/bin/vite.js build
cd ../BeeMiniPOS
node --experimental-strip-types --test src/*.test.ts
node node_modules/typescript/bin/tsc --noEmit
node scripts/build-web.mjs production
```

Full PWA tests require `go` in PATH and the adjacent `fiscal-backend`/`contracts` plus existing shared-ui workspace files. The last Expo command is OPEN here for the dependency-isolation reason above, not a claimed PASS.

`reproduce-counterfactual.py CHECKOUT OUTPUT` runs the stable-id negative control, restores byte-identical helpers in `finally`, then verifies the restored case is green. It refuses any checkout outside `/private/tmp` because it intentionally mutates a disposable copy. Negative control is mandatory red; unexpected green is an error.

## Acceptance boundaries

See `PLAN.md` for API/wire/ownership details. Default185 legacy offer is preserved; default ATT23/value20 is unsupported (BFF1 header57, min value58/MTU61). Rejected writes are never resized or retried. Opaque `device.id` is lifecycle admission, not authenticated identity. Cross-tab/cross-bundle/OS connections, physical devices, ATT negotiated capacity, throughput/latency, native Android/iOS SDK behavior, new reliable stream callback integration, authenticated/encrypted BLE and S3 heap remain OPEN. Secure-channel/TLS completion and financial certification are not claimed. Keys remain ESP32-S3/NVS; ATECC608A/608 is not used.
